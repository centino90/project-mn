export default () => ({
    on: false,
 
    toggle() {
        this.on = ! this.on
    }
})