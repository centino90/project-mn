<?php
// DB Params
define('DB_HOST', 'localhost');
define('DB_USER', 'u704967255_centino90');
define('DB_PASS', 'Tropawzpoge123');
define('DB_NAME', 'u704967255_PaymentSystem');

// fb credentials
define('FB_APP_ID', '4649891738473679');
define('FB_APP_SECRET', '3f981db9771fa424b0870a9eb4e4a4f4');
define('FB_REDIRECT_URI', 'https://www.pda-dcc.com/users/redirectPage');

// GOOGLE credentials
define('GOOGLE_CLIENT_ID', '716149094685-4no609952083305njj3n077nbd3kf61r.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');
define('GOOGLE_REDIRECT_URI', 'https://www.pda-dcc.com/users/redirectPage');

// Google RECAPTCHA credentials
define('RECAPTCHA_SITEKEY', '6LcpA30dAAAAAOVfY5fIQgV5BDZsAtBnpo8lkdW1');
define('RECAPTCHA_SECRET', '6LcpA30dAAAAAGQnG5gzHeDcSiOMEfEaz8_93-a1');

// MAIL settings
define('MAIL_MAILER', 'smtp');
define('MAIL_HOST', 'smtp.hostinger.com');
define('MAIL_PORT', '587');
define('MAIL_USERNAME', 'admin@pda-dcc.com');
define('MAIL_PASSWORD', 'MH7PHcJj3:d2];kYym]dC9)u}');
define('MAIL_ENCRYPTION', null);
define('MAIL_FROM_ADDRESS', 'admin@pda-dcc.com');
define('MAIL_FROM_NAME', 'PDA-DCC');
